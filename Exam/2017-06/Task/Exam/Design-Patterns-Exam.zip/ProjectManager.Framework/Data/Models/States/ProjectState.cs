﻿namespace ProjectManager.Framework.Data.Models.States
{
    public enum ProjectState
    {
        Active = 0,
        Inactive = 1
    }
}
