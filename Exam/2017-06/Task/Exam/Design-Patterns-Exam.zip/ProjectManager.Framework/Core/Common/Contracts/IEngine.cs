﻿namespace ProjectManager.Framework.Core.Common.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
